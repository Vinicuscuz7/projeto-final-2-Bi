# attFinal2BI
 Atividade Acadêmica. 
